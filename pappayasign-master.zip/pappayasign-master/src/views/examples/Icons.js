import React from "react";
// react component that copies the given text inside your clipboard
import { CopyToClipboard } from "react-copy-to-clipboard";
import PDFAnnotate from '../../components/PDFAnnotate/pdfannotate'
// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Container,
  Row,
  Col,
  UncontrolledTooltip
} from "reactstrap";
// core components
import HeaderDefault from "components/Headers/HeaderDefault.js";

class Icons extends React.Component {
  state = {};
  render() {
    return (
      <>
        <HeaderDefault />
        {/* Page content */}
        <Container className=" mt--7">
        <Card className=" shadow">
                <CardBody>
                 <PDFAnnotate/>
                </CardBody>
              </Card>
        </Container>
      </>
    );
  }
}

export default Icons;
