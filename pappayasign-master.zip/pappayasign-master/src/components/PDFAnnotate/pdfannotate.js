import React, { Fragment } from 'react'
import PropTypes from 'prop-types'
import $ from 'jquery';
import { fabric } from 'fabric';
import * as jsPDF from 'jspdf';
//import fabric from 'fabric-webpack'
import "./styles.css";
import "./pdfannotate.css";

var PDFJS = require("pdfjs-dist");
//var fabric = require("fabric-webpack");
//var jsPDF = require("jspdf-react");
var pdfPath = "./sample.pdf";
const pdfjsWorker = require('pdfjs-dist/build/pdf.worker.entry');

class PDFAnnotate extends React.Component {
 
componentDidMount() { 
var PDFAnnotate = function(container_id, toolbar_id, url, filename, options = {}) {
	this.number_of_pages = 0;
	this.pages_rendered = 0;
	this.active_tool = 1; // 1 - Free hand, 2 - Text, 3 - Arrow, 4 - Rectangle
	this.fabricObjects = [];
	this.fabricObjectsData = [];
	this.color = '#000';
	this.borderColor = '#000000';
	this.borderSize = 1;
	this.font_size = 16;
	this.active_canvas = 0;
	this.container_id = container_id;
	this.toolbar_id = toolbar_id;
	this.imageurl = '';
	this.filename = filename;
	this.url = url;
	var inst = this;

	var loadingTask = PDFJS.getDocument(this.url);
	loadingTask.promise.then(function (pdf) {
	    var scale = 1.3;
	    inst.number_of_pages = pdf.numPages;

	    for (var i = 1; i <= pdf.numPages; i++) {
	        pdf.getPage(i).then(function (page) {
	            var viewport = page.getViewport(scale);
	            var canvas = document.createElement('canvas');
	            document.getElementById(inst.container_id).appendChild(canvas);
	            canvas.className = 'pdf-canvas';
	            canvas.height = viewport.height;
	            canvas.width = viewport.width;
	            var context = canvas.getContext('2d');

	            var renderContext = {
	                canvasContext: context,
	                viewport: viewport
	            };
	            var renderTask = page.render(renderContext);
	            renderTask.then(function () {
	                $('.pdf-canvas').each(function (index, el) {
	                    $(el).attr('id', 'page-' + (index + 1) + '-canvas');
	                });
	                inst.pages_rendered++;
	                if (inst.pages_rendered == inst.number_of_pages) inst.initFabric();
	            });
	        });
	    }
	}, function (reason) {
	    console.error(reason);
	});

	this.initFabric = function () {
		var inst = this;
	    $('#' + inst.container_id + ' canvas').each(function (index, el) {
	        var background = el.toDataURL("image/png");
	        var fabricObj = new fabric.Canvas(el.id, {
	            freeDrawingBrush: {
	                width: 1,
	                color: inst.color
	            }
	        });
		
		fabricObj.on('object:selected', function (e) {
		  e.target.transparentCorners = false;
		  e.target.borderColor = '#cccccc';
		  e.target.cornerColor = '#d35400';
		  e.target.minScaleLimit = 2;
		  e.target.cornerStrokeColor = '#d35400';
		  e.target.cornerSize = 8;
		  e.target.cornerStyle = 'circle';
		  e.target.minScaleLimit = 0;
		  e.target.lockScalingFlip = false;
		  e.target.padding = 5;
		  e.target.selectionDashArray = [10, 5];
		  e.target.borderDashArray = [10, 5];
		});
			inst.fabricObjects.push(fabricObj);
			if (typeof options.onPageUpdated == 'function') {
				fabricObj.on('object:added', function() {
					var oldValue = Object.assign({}, inst.fabricObjectsData[index]);
					inst.fabricObjectsData[index] = fabricObj.toJSON()
					options.onPageUpdated(index + 1, oldValue, inst.fabricObjectsData[index]) 
				})
			}
	        fabricObj.setBackgroundImage(background, fabricObj.renderAll.bind(fabricObj));
	        $(fabricObj.upperCanvasEl).click(function (event) {
	            inst.active_canvas = index;
	            inst.fabricClickHandler(event, fabricObj);
			});
			fabricObj.on('after:render', function () {
				inst.fabricObjectsData[index] = fabricObj.toJSON()
				fabricObj.off('after:render')
			})
		});
	}
	
	

	this.fabricClickHandler = function(event, fabricObj) {
		var inst = this;
		
	    if (inst.active_tool == 2) {
	        var text = new fabric.IText('Sample text', {
	            left: event.clientX - fabricObj.upperCanvasEl.getBoundingClientRect().left,
	            top: event.clientY - fabricObj.upperCanvasEl.getBoundingClientRect().top,
	            fill: inst.color,
	            fontSize: inst.font_size,
	            selectable: true
	        });
	        fabricObj.add(text);
	        inst.active_tool = 0;
		 		
		$('.icon-color').removeClass('icon-color');
	    }
	    else if (inst.active_tool == 4) {		        
		var myImg = inst.imageurl;
		fabric.Image.fromURL(myImg, function(oImg) {
		var l = event.clientX - fabricObj.upperCanvasEl.getBoundingClientRect().left - 100;
		var t = event.clientY - fabricObj.upperCanvasEl.getBoundingClientRect().top - 20;                
		oImg.scale(0.5);
		oImg.set({'left':l});
		  oImg.set({'top':t});
		fabricObj.add(oImg);
		
		},{ crossOrigin: 'Anonymous' });
		inst.active_tool = 0;
	    }
	    else if (inst.active_tool == 5) {		        
		        
		var rect = new fabric.Rect({
		left:event.clientX - fabricObj.upperCanvasEl.getBoundingClientRect().left - 100,
		top:event.clientY - fabricObj.upperCanvasEl.getBoundingClientRect().top - 20,
		width: 100,
		height: 100,
		fill: 'rgba(0,0,0,0)',
		stroke: inst.color,
		strokeSize: inst.borderSize
		});
		fabricObj.add(rect);
		
		inst.active_tool = 0;
		$('.icon-color').removeClass('icon-color');
	    }
	    else if (inst.active_tool == 6) {		        
		        
		var circle = new fabric.Circle({
		left:event.clientX - fabricObj.upperCanvasEl.getBoundingClientRect().left - 100,
		top:event.clientY - fabricObj.upperCanvasEl.getBoundingClientRect().top - 20,
		radius:50,
		fill: 'rgba(0,0,0,0)',
		stroke: inst.color,
		strokeSize: inst.borderSize
		});
		fabricObj.add(circle);
		
		inst.active_tool = 0;
		$('.icon-color').removeClass('icon-color');
	    }
	}
	
	
}

PDFAnnotate.prototype.enableSelector = function () {
	var inst = this;
	inst.active_tool = 0;
	if (inst.fabricObjects.length > 0) {
	    $.each(inst.fabricObjects, function (index, fabricObj) {
	        fabricObj.isDrawingMode = false;
	    });
	}
}

PDFAnnotate.prototype.enablePencil = function () {
	var inst = this;
	inst.active_tool = 1;
	if (inst.fabricObjects.length > 0) {
	    $.each(inst.fabricObjects, function (index, fabricObj) {
	        fabricObj.isDrawingMode = true;
	    });
	}
}

PDFAnnotate.prototype.enableAddText = function () {
	var inst = this;
	inst.active_tool = 2;
	if (inst.fabricObjects.length > 0) {
	    $.each(inst.fabricObjects, function (index, fabricObj) {
	        fabricObj.isDrawingMode = false;
	    });
	}
}

PDFAnnotate.prototype.enableImage = function (url) {
	var inst = this;
	var fabricObj = inst.fabricObjects[inst.active_canvas];
	inst.active_tool = 4;
	inst.imageurl = url;
	if (inst.fabricObjects.length > 0) {
	    $.each(inst.fabricObjects, function (index, fabricObj) {
	        fabricObj.isDrawingMode = false;
	    });
	}
}


PDFAnnotate.prototype.enableRectangle = function () {
	var inst = this;
	var fabricObj = inst.fabricObjects[inst.active_canvas];
	inst.active_tool = 5;
	if (inst.fabricObjects.length > 0) {
		$.each(inst.fabricObjects, function (index, fabricObj) {
			fabricObj.isDrawingMode = false;
		});
	}
}

PDFAnnotate.prototype.enableCircle= function () {
	var inst = this;
	var fabricObj = inst.fabricObjects[inst.active_canvas];
	inst.active_tool = 6;
	if (inst.fabricObjects.length > 0) {
		$.each(inst.fabricObjects, function (index, fabricObj) {
			fabricObj.isDrawingMode = false;
		});
	}
}

PDFAnnotate.prototype.deleteSelectedObject = function () {
	var inst = this;
	var activeObject = inst.fabricObjects[inst.active_canvas].getActiveObject();
	if (activeObject)
	{
	     inst.fabricObjects[inst.active_canvas].remove(activeObject);
	}
}

PDFAnnotate.prototype.ZoomIn = function () {
	var inst = this;
	var fabricObj = inst.fabricObjects[inst.active_canvas];
	if (inst.fabricObjects.length > 0) {
	    $.each(inst.fabricObjects, function (index, fabricObj) {
	        fabricObj.setHeight(fabricObj.getHeight() / 1.5);
	fabricObj.setWidth(fabricObj.getWidth() / 1.5);
	    });
	}
	
	
}



PDFAnnotate.prototype.savePdf = function () {
	var inst = this;
	var doc = new jsPDF();
	$.each(inst.fabricObjects, function (index, fabricObj) {
	    if (index != 0) {
	        doc.addPage();
	        doc.setPage(index + 1);
	    }
	    doc.addImage(fabricObj.toDataURL(), 'png', 0, 0);
	});
	doc.save('pappayasign_'+inst.filename+'');
}

PDFAnnotate.prototype.setBrushSize = function (size) {
	var inst = this;
	$.each(inst.fabricObjects, function (index, fabricObj) {
	    fabricObj.freeDrawingBrush.width = size;
	});
}

PDFAnnotate.prototype.setColor = function (color) {
	var inst = this;
	inst.color = color;
	$.each(inst.fabricObjects, function (index, fabricObj) {
        fabricObj.freeDrawingBrush.color = color;
    });
}

PDFAnnotate.prototype.setBorderColor = function (color) {
	var inst = this;
	inst.borderColor = color;
}

PDFAnnotate.prototype.setFontSize = function (size) {
	this.font_size = size;
}

PDFAnnotate.prototype.setBorderSize = function (size) {
	this.borderSize = size;
}

PDFAnnotate.prototype.clearActivePage = function () {
	var inst = this;
	var fabricObj = inst.fabricObjects[inst.active_canvas];
	var bg = fabricObj.backgroundImage;
	    fabricObj.clear();
	    fabricObj.setBackgroundImage(bg, fabricObj.renderAll.bind(fabricObj));

}

PDFAnnotate.prototype.serializePdf = function() {
	var inst = this;
	return JSON.stringify(inst.fabricObjects, null, 4);
}



PDFAnnotate.prototype.loadFromJSON = function(jsonData) {
	var inst = this;
	$.each(inst.fabricObjects, function (index, fabricObj) {
		if (jsonData.length > index) {
			fabricObj.loadFromJSON(jsonData[index], function () {
				inst.fabricObjectsData[index] = fabricObj.toJSON()
			})
		}
	})
}



var pdf = new PDFAnnotate('pdf-container', 'toolbar', '/pdf.pdf', 'defaultfile', {
    onPageUpdated: (page, oldData, newData) => {
        console.log(page, oldData, newData);
    }

});



document.getElementById('fileinput').addEventListener('input', function(input) {
	try {
		console.log(input.target.value);
	console.log(input.srcElement.files[0].name);

    var file = input.srcElement.files[0];
	console.log(input.srcElement.files[0].name);

  var reader = new FileReader();
    reader.readAsDataURL(file);

  reader.onload = function() {
     var url = reader.result;
     clearPDF();
    pdf = new PDFAnnotate('pdf-container', 'toolbar', url, input.srcElement.files[0].name);
  };

  reader.onerror = function() {
    console.log(reader.error);
    alert('Error Opening File');
  };
	} catch (error) {
		console.log(error);
	}
	
});


document.getElementById('imageinput').addEventListener('input', function(input) {
	try {
		console.log(input.target.value);
	console.log(input.srcElement.files[0].name);
    var file = input.srcElement.files[0];
	console.log(input.srcElement.files[0].name);

  var reader = new FileReader();
    reader.readAsDataURL(file);

  reader.onload = function() {
     var url = reader.result;
     pdf.enableImage(url);
  };

  reader.onerror = function() {
    console.log(reader.error);
    alert('Error Opening File');
  };
	} catch (error) {
		console.log(error)
	}
	
});

var clearbtn = document.getElementById('clearbtn');
clearbtn.addEventListener('click', function(event) {
	$('.icon-color').removeClass('icon-color');
    pdf.clearActivePage();
});

var deletebtn = document.getElementById('deletebtn');
deletebtn.addEventListener('click', function(event) {
	$('.icon-color').removeClass('icon-color');
     pdf.deleteSelectedObject();
});

var savebtn = document.getElementById('savebtn');
savebtn.addEventListener('click', function(event) {
	$('.icon-color').removeClass('icon-color');
     pdf.savePdf();
});

var selectbtn = document.getElementById('selectbtn');
selectbtn.addEventListener('click', function(event) {
     var element = ($(event.target).hasClass('tool-button')) ? $(event.target) : $(event.target).parents('.tool-button').first();
    $('.tool-button.active').removeClass('active');
    $('.icon-color').removeClass('icon-color');
    $(element).addClass('active');
    const icon = this.querySelector('i');
    icon.classList.add('icon-color');
    pdf.enableSelector();
});

var rectanglebtn = document.getElementById('rectanglebtn');
rectanglebtn.addEventListener('click', function(event) {
     var element = ($(event.target).hasClass('tool-button')) ? $(event.target) : $(event.target).parents('.tool-button').first();
    $('.tool-button.active').removeClass('active');
    $('.icon-color').removeClass('icon-color');
    $(element).addClass('active');
    const icon = this.querySelector('i');
    icon.classList.add('icon-color');
    pdf.enableRectangle();
});

var circlebtn = document.getElementById('circlebtn');
circlebtn.addEventListener('click', function(event) {
     var element = ($(event.target).hasClass('tool-button')) ? $(event.target) : $(event.target).parents('.tool-button').first();
    $('.tool-button.active').removeClass('active');
    $('.icon-color').removeClass('icon-color');
    $(element).addClass('active');
    const icon = this.querySelector('i');
    icon.classList.add('icon-color');
    pdf.enableCircle();
});


var textbtn = document.getElementById('textbtn');
textbtn.addEventListener('click', function(event) {
    var element = ($(event.target).hasClass('tool-button')) ? $(event.target) : $(event.target).parents('.tool-button').first();
    $('.tool-button.active').removeClass('active');
    $('.icon-color').removeClass('icon-color');
    $(element).addClass('active');
    const icon = this.querySelector('i');
    icon.classList.add('icon-color');
    pdf.enableAddText();
});

var penbtn = document.getElementById('penbtn');
penbtn.addEventListener('click', function(event) {
    var element = ($(event.target).hasClass('tool-button')) ? $(event.target) : $(event.target).parents('.tool-button').first();
    $('.tool-button.active').removeClass('active');
    $('.icon-color').removeClass('icon-color');
    $(element).addClass('active');
    const icon = this.querySelector('i');
    icon.classList.add('icon-color');
    pdf.enablePencil();
});

var openfilebtn = document.getElementById('openfilebtn');
openfilebtn.addEventListener('click', function(event) {
	$('.icon-color').removeClass('icon-color');
    document.getElementById("fileinput").click();
});


var imagebtn = document.getElementById('imagebtn');
imagebtn.addEventListener('click', function(event) {
	$('.icon-color').removeClass('icon-color');
    document.getElementById("imageinput").click();
});

function clearPDF() {
    const myNode = document.getElementById("pdf-container");
    myNode.innerHTML = '';
}

function clickFile() {
	$('.icon-color').removeClass('icon-color');
	var inputtag = document.createElement('span');
	inputtag.innerHTML = '<input id="fileinput" type="file" accept="application/pdf" value="Click me" onchange="openPDF(this)" style="display:none;">'
	document.getElementById('toolbar').appendChild(inputtag);
    document.getElementById("fileinput").click();
}

function clickImageFile() {
	$('.icon-color').removeClass('icon-color');
	var imagetag = document.createElement('span');
	imagetag.innerHTML = '<input id="imageinput" type="file" accept="image/*" value="Click me" onchange="openImage(this)" style="display:none;">'
	document.getElementById('toolbar').appendChild(imagetag);
    document.getElementById("imageinput").click();
}


function clearPage() {
    pdf.clearActivePage();
}

$('.color-tool').click(function () {
$('.color-tool.active').removeClass('active');
$(this).addClass('active');
$('.icon-color').removeClass('icon-color');
var color = $(this).get(0).style.backgroundColor;
pdf.setColor(color);
});

var colortool = document.getElementById('colortool');
colortool.addEventListener('input', function(event) {
    console.log('color');
    
    var colord = colortool.value;
     var selectcolor = document.getElementById('selectcolor');
    selectcolor.style.backgroundColor  = colord;
    console.log(colord);
    pdf.setColor(colord);
});

var selectcolor = document.getElementById('selectcolor');
selectcolor.addEventListener('click', function(event) {
	$('.icon-color').removeClass('icon-color');
    document.getElementById("colortool").click();
});

}

render() {
    
    return (
	<div id="container">
	<div id="toolbar" className="toolbar">
	
	<button id="openfilebtn" className="tool"><i className="material-icons" >insert_drive_file</i></button>
	<button id="savebtn" className="tool"><i className="material-icons" >get_app</i></button>
	<button id="penbtn" className="tool"><i className="material-icons" >edit</i></button>
	<button id="textbtn" className="tool"><i className=" material-icons" >text_fields</i></button>
	<button id="selectbtn" className="tool"><i className="material-icons" >pan_tool</i></button>
	<button id="imagebtn" className="tool"><i className="material-icons" >image</i></button>
	<button id="circlebtn" className="tool"><i className="material-icons" >panorama_fish_eye</i></button>
	<button id="rectanglebtn" className="tool"><i className="material-icons" >crop_din</i></button>
	<button id="deletebtn" className="tool"><i className="material-icons" >delete_forever</i></button>
	
	<input id="fileinput" type="file" accept="application/pdf"></input>
	<input id="imageinput" type="file" accept="image/*"></input>
	
	<button className="color-tool" id="selectcolor" style={{backgroundColor: '#000000'}}></button>
	<input type="color" className="color-tool" id="colortool" name="favcolor"></input>
	<button id="clearbtn" className="tool"><i className="material-icons" >clear</i></button>
	</div>
	<div id="pdf-container" style={{
		height: '450px',
		overflow: 'auto'
	}}></div>
	</div>
    )
  }

}

export default PDFAnnotate;