
import React from "react";
import { Link } from "react-router-dom";

// reactstrap components
import { NavItem, NavLink, Nav, Container, Row, Col } from "reactstrap";

class Login extends React.Component {
  render() {
    return (
      <>
        <footer className="py-5">
          <Container>
            <Row className="align-items-center justify-content-xl-between">
              
              <Col xl="6">
                <Nav className="nav-footer justify-content-center justify-content-xl-start">
                <NavItem>
                <NavLink
                 to="/" tag={Link}
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  Home
                </NavLink>
              </NavItem>

              <NavItem>
                <NavLink
                  to="/admin/icons" tag={Link}
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  Sign
                </NavLink>
              </NavItem>

              <NavItem>
                <NavLink
                  to="/admin/tables" tag={Link}
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  Manage
                </NavLink>
              </NavItem>

              <NavItem>
                <NavLink
                  to="/auth/login" tag={Link}
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  Settings
                </NavLink>
              </NavItem>
                </Nav>
              </Col>

              <Col xl="6">
                <div className="copyright text-center text-xl-right text-muted">
                  © 2020{" "}
                  <a
                    className="font-weight-bold ml-1"
                    href="#"
                    target="_blank"
                  >
                    Pappaya
                  </a>
                </div>
              </Col>
            </Row>
          </Container>
        </footer>
      </>
    );
  }
}

export default Login;
