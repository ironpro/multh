import React from "react";
import { Link, NavLink } from "react-router-dom";
import $ from 'jquery';
// reactstrap components
import {
  Button,
  UncontrolledCollapse,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
  DropdownToggle,
  Media,
  NavbarBrand,
  Navbar,
  NavItem,
  Nav,
  Container,
  Row,
  Col
} from "reactstrap";

class AdminNavbar extends React.Component {
  componentDidMount() { 
 
  }
  render() {
    return (
      <>
      <Navbar
        className="navbar-top navbar-horizontal navbar-dark"
        expand="md"
      >
        <Container className="px-4" fluid>
            <img alt="..." style={{ maxWidth: "170px" }} src={require("assets/img/brand/pappayasign_white.png")} />
          <button className="navbar-toggler" id="navbar-collapse-main">
            <span className="navbar-toggler-icon" />
          </button>
          <UncontrolledCollapse navbar toggler="#navbar-collapse-main">
            <div className="navbar-collapse-header d-md-none">
              <Row>
                <Col className="collapse-brand" xs="6">
                  <Link to="/">
                    <img
                      alt="..."
                      src={require("assets/img/brand/argon-react.png")}
                    />
                  </Link>
                </Col>
                <Col className="collapse-close" xs="6">
                  <button
                    className="navbar-toggler"
                    id="navbar-collapse-main"
                  >
                    <span />
                    <span />
                  </button>
                </Col>
              </Row>
            </div>
            <Nav className="ml-auto mr-auto" fluid="true" navbar>
              <NavItem>
                <NavLink id="homebtn" className="nav-link-icon navtop " activeClassName="active"  to="/admin/index" tag={Link}>
                <span className="btn-inner--icon">
                  <i className="material-icons" >home</i>
                  </span>
                  <span className="btn-inner--text">Home</span>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink id="signbtn" className="nav-link-icon navtop" activeClassName="active" to="/admin/icons" tag={Link}>
                <span className="btn-inner--icon">
                  <i className="material-icons" >edit</i>
                  </span>
                  <span className="btn-inner--text">Sign</span>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink id="managebtn" className="nav-link-icon navtop" activeClassName="active" to="/admin/tables" tag={Link}>
                <span className="btn-inner--icon">
                  <i className="material-icons" >chrome_reader_mode</i>
                  </span>
                  <span className="btn-inner--text">Manage</span>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink id="settingsbtn" className="nav-link-icon navtop" activeClassName="active" to="/auth/login" tag={Link}>
                <span className="btn-inner--icon">
                  <i className="material-icons" >settings</i>
                  </span>
                  <span className="btn-inner--text">Settings</span>
                </NavLink>
              </NavItem>
            </Nav>
            <Nav className="align-items-center d-none d-md-flex" navbar>
            <UncontrolledDropdown nav>
              <DropdownToggle className="pr-0" nav>
                <Media className="align-items-center">
                  <span className="avatar avatar-sm rounded-circle">
                    <img
                      alt="..."
                      src={require("assets/img/theme/team-4-800x800.jpg")}
                    />
                  </span>
                  <Media className="ml-2 d-none d-lg-block">
                    <span className="mb-0 text-sm font-weight-bold">
                      Jessica Jones
                    </span>
                  </Media>
                </Media>
              </DropdownToggle>
              <DropdownMenu className="dropdown-menu-arrow" right>
                <DropdownItem to="/admin/user-profile" tag={Link}>
                  <i className="ni ni-single-02" />
                  <span>My profile</span>
                </DropdownItem>
                <DropdownItem to="/admin/user-profile" tag={Link}>
                  <i className="ni ni-settings-gear-65" />
                  <span>Settings</span>
                </DropdownItem>
                <DropdownItem to="/admin/user-profile" tag={Link}>
                  <i className="ni ni-calendar-grid-58" />
                  <span>Activity</span>
                </DropdownItem>
                <DropdownItem to="/admin/user-profile" tag={Link}>
                  <i className="ni ni-support-16" />
                  <span>Support</span>
                </DropdownItem>
                <DropdownItem divider />
                <DropdownItem href="#pablo" onClick={e => e.preventDefault()}>
                  <i className="ni ni-user-run" />
                  <span>Logout</span>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </Nav>
          </UncontrolledCollapse>
        </Container>
      </Navbar>
    </>
    );
  }
}

export default AdminNavbar;
